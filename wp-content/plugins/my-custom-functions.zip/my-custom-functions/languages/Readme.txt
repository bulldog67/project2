
CONTRIBUTING YOUR TRANSLATION


This plugin is ready for translation and has already been translated into several languages.

If you want to help translate this plugin then please visit the [translation page](https://translate.wordpress.org/projects/wp-plugins/my-custom-functions).

You can also use the POT file, that is included and placed in the "languages" folder, in order to create a translation PO file. Just send the PO file to us (https://www.spacexchimp.com/contact.html) and we will include this translation within the next plugin update.

Maybe not all existed translations are up to date. You are welcome to contribute corrections!

Many of plugin users would be delighted if you share your translation with the community. Thanks for your contribution!
